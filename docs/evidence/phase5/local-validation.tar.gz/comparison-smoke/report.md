# Repeated transport measurements

15 successful trials; 8 measured requests per trial; 1 repetitions per configuration. All warm-up/measured outputs verified.

Values below are the median of per-trial statistics, with the minimum–maximum range across trials. Raw latencies are not pooled across trials. Queue depth, slot capacity, and instrumentation remain explicit. CPU simulator on the recorded host; no native Mac, ARM64 or NPU inference is established.

| Mode / slots | KiB | In flight | Workload | Delay μs | Timed | p50 μs | p95 μs | p99 μs [min–max] | requests/s [min–max] |
|---|---:|---:|---|---:|---:|---:|---:|---:|---:|
| shm-async / 0 | 4 | 1 | compute | 0 | 1 | 158.1 | 365.3 | 365.3 [365.3–365.3] | 3718.2 [3718.2–3718.2] |
| shm-async / 0 | 4 | 1 | noop | 0 | 1 | 171.6 | 275.7 | 275.7 [275.7–275.7] | 4329.8 [4329.8–4329.8] |
| shm-async / 0 | 4 | 4 | compute | 0 | 1 | 328.7 | 565.8 | 565.8 [565.8–565.8] | 8207.3 [8207.3–8207.3] |
| shm-async / 0 | 4 | 4 | noop | 0 | 1 | 376.3 | 762.8 | 762.8 [762.8–762.8] | 6820.4 [6820.4–6820.4] |
| shm-double-buffer / 2 | 4 | 1 | compute | 0 | 1 | 69.5 | 254.8 | 254.8 [254.8–254.8] | 7408.9 [7408.9–7408.9] |
| shm-double-buffer / 2 | 4 | 1 | noop | 0 | 1 | 66.2 | 151.0 | 151.0 [151.0–151.0] | 11209.9 [11209.9–11209.9] |
| shm-double-buffer / 2 | 4 | 4 | compute | 0 | 1 | 105.9 | 170.4 | 170.4 [170.4–170.4] | 25205.6 [25205.6–25205.6] |
| shm-double-buffer / 2 | 4 | 4 | noop | 0 | 1 | 328.0 | 821.4 | 821.4 [821.4–821.4] | 5711.9 [5711.9–5711.9] |
| socket-async / 0 | 4 | 1 | compute | 0 | 1 | 60.1 | 119.8 | 119.8 [119.8–119.8] | 9000.5 [9000.5–9000.5] |
| socket-async / 0 | 4 | 1 | noop | 0 | 0 | 149.0 | 243.9 | 243.9 [243.9–243.9] | 4598.9 [4598.9–4598.9] |
| socket-async / 0 | 4 | 1 | noop | 0 | 1 | 106.6 | 624.8 | 624.8 [624.8–624.8] | 4338.3 [4338.3–4338.3] |
| socket-async / 0 | 4 | 4 | compute | 0 | 1 | 116.8 | 132.2 | 132.2 [132.2–132.2] | 25767.9 [25767.9–25767.9] |
| socket-async / 0 | 4 | 4 | noop | 0 | 1 | 100.0 | 121.4 | 121.4 [121.4–121.4] | 28428.2 [28428.2–28428.2] |
| socket-sync / 0 | 4 | 1 | compute | 0 | 1 | 138.2 | 320.8 | 320.8 [320.8–320.8] | 5321.4 [5321.4–5321.4] |
| socket-sync / 0 | 4 | 1 | noop | 0 | 1 | 60.3 | 100.5 | 100.5 [100.5–100.5] | 12472.3 [12472.3–12472.3] |

`summary.csv` retains mean, sample standard deviation, median, min and max of each per-trial metric, including initialization, first request, stage means and measured socket bytes. `trials.csv` preserves each trial's statistics. Manifest entries link exact commands, raw CSVs, summaries and errors.

**Smoke validation only: fewer than five repetitions; do not publish performance comparisons.**

![Latency](latency.svg)
![Throughput](throughput.svg)
![Concurrency](concurrency.svg)
![Client startup](startup.svg)
![Stages](stages.svg)
![Socket traffic](traffic.svg)
