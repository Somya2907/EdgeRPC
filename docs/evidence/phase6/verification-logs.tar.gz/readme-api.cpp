#include <edgerpc/client.hpp>
int main(int argc, char** argv) {
if (argc != 2) return 2;


edgerpc::EdgeRpcClient client(argv[1]);
auto sync = client.infer_sync({-1.0f, 0.0f, 2.0f}); // {-1, 1, 5}
auto pending = client.infer_async({1.0f, 2.0f});
auto result = pending.get();
auto shared = client.infer_async({3.0f}, edgerpc::Operation::Compute,
                               edgerpc::TensorTransport::SharedMemory).get();
return sync.output == std::vector<float>{-1,1,5} && result.output == std::vector<float>{3,5} && shared.output == std::vector<float>{7} ? 0 : 1;
}
