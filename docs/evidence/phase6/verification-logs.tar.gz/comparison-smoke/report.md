# Repeated transport measurements

15 successful trials; 8 measured requests per trial; 1 repetitions per configuration. All warm-up/measured outputs verified.

Values below are the median of per-trial statistics, with the minimum–maximum range across trials. Raw latencies are not pooled across trials. Queue depth, slot capacity, and instrumentation remain explicit. CPU simulator on the recorded host; no native Mac, ARM64 or NPU inference is established.

| Mode / slots | KiB | In flight | Workload | Delay μs | Timed | p50 μs | p95 μs | p99 μs [min–max] | requests/s [min–max] |
|---|---:|---:|---|---:|---:|---:|---:|---:|---:|
| shm-async / 0 | 4 | 1 | compute | 0 | 1 | 135.8 | 261.6 | 261.6 [261.6–261.6] | 5165.2 [5165.2–5165.2] |
| shm-async / 0 | 4 | 1 | noop | 0 | 1 | 166.7 | 476.8 | 476.8 [476.8–476.8] | 3753.5 [3753.5–3753.5] |
| shm-async / 0 | 4 | 4 | compute | 0 | 1 | 245.3 | 416.5 | 416.5 [416.5–416.5] | 12305.6 [12305.6–12305.6] |
| shm-async / 0 | 4 | 4 | noop | 0 | 1 | 218.7 | 447.0 | 447.0 [447.0–447.0] | 11149.6 [11149.6–11149.6] |
| shm-double-buffer / 2 | 4 | 1 | compute | 0 | 1 | 39.8 | 151.9 | 151.9 [151.9–151.9] | 14023.4 [14023.4–14023.4] |
| shm-double-buffer / 2 | 4 | 1 | noop | 0 | 1 | 32.3 | 53.1 | 53.1 [53.1–53.1] | 20565.9 [20565.9–20565.9] |
| shm-double-buffer / 2 | 4 | 4 | compute | 0 | 1 | 103.4 | 124.5 | 124.5 [124.5–124.5] | 32116.5 [32116.5–32116.5] |
| shm-double-buffer / 2 | 4 | 4 | noop | 0 | 1 | 233.0 | 422.1 | 422.1 [422.1–422.1] | 11395.5 [11395.5–11395.5] |
| socket-async / 0 | 4 | 1 | compute | 0 | 1 | 91.9 | 212.1 | 212.1 [212.1–212.1] | 7876.3 [7876.3–7876.3] |
| socket-async / 0 | 4 | 1 | noop | 0 | 0 | 89.7 | 354.9 | 354.9 [354.9–354.9] | 6541.2 [6541.2–6541.2] |
| socket-async / 0 | 4 | 1 | noop | 0 | 1 | 63.3 | 167.8 | 167.8 [167.8–167.8] | 10230.6 [10230.6–10230.6] |
| socket-async / 0 | 4 | 4 | compute | 0 | 1 | 147.6 | 268.2 | 268.2 [268.2–268.2] | 15479.0 [15479.0–15479.0] |
| socket-async / 0 | 4 | 4 | noop | 0 | 1 | 84.4 | 288.4 | 288.4 [288.4–288.4] | 17914.8 [17914.8–17914.8] |
| socket-sync / 0 | 4 | 1 | compute | 0 | 1 | 196.7 | 409.6 | 409.6 [409.6–409.6] | 3785.3 [3785.3–3785.3] |
| socket-sync / 0 | 4 | 1 | noop | 0 | 1 | 41.5 | 91.7 | 91.7 [91.7–91.7] | 15951.8 [15951.8–15951.8] |

`summary.csv` retains mean, sample standard deviation, median, min and max of each per-trial metric, including initialization, first request, stage means and measured socket bytes. `trials.csv` preserves each trial's statistics. Manifest entries link exact commands, raw CSVs, summaries and errors.

**Smoke validation only: fewer than five repetitions; do not publish performance comparisons.**

![Latency](latency.svg)
![Throughput](throughput.svg)
![Concurrency](concurrency.svg)
![Client startup](startup.svg)
![Stages](stages.svg)
![Socket traffic](traffic.svg)
